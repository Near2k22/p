<?php
/**
 * Default database config
 * define("DB_HOST","localhost");
 * define("DB_NAME","wovie");
 * define("DB_USER","root");
 * define("DB_PASS","");
 */

define("DB_HOST","localhost");
define("DB_NAME","wovie");
define("DB_USER","root");
define("DB_PASS","");
