<?php
/**
 * Default database config
 * define("DB_HOST","localhost");
 * define("DB_NAME","wovie");
 * define("DB_USER","root");
 * define("DB_PASS","");
 */

define("DB_HOST","ls-2c20fdc8ebfbaddd5868e4c5c0181b67dc2b9548.cvnoxulv7tpe.us-west-2.rds.amazonaws.com");
define("DB_NAME","Database-1");
define("DB_USER","dbmasteruser");
define("DB_PASS","|`FQ})qFBy)|XtVI`3d1mBbAL#?`S&_?");
