<?php
$Qualities = array('CAM','SD','HD','Ultra HD');
$Reports = array(
      '1'		=> __('Video Issue'),
      '4'		=> __('Website Issue')
);
$Jquery = array(
      THEME.'/js/jquery.min.js',
      THEME.'/js/bootstrap.bundle.js',
      THEME.'/js/jquery.lazy.js',
      THEME.'/js/jquery.snackbar.js',
      THEME.'/js/jquery.typeahead.js',
      THEME.'/js/jquery.tmpl.js',
      THEME.'/js/jquery.comment.js',
      THEME.'/js/detail.js',
      THEME.'/js/app.js'
);
$JqueryPlayer = array(
      THEME.'/js/plyr.js',
      THEME.'/js/plyr.hls.js',
);