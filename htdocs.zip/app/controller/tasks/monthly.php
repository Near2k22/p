<?php

$db = new mysqli("localhost","watcha","AlphaBravo12","watcha");

// set hits to 0 weekly
$db->query('UPDATE posts SET hits_monthly = 0');

?>
