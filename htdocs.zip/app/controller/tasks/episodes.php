<?php

include '../../config/db.config.php'; // Database configuration 

$link = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
$sql = "SELECT posts.id as postid, posts.title, posts.type, posts_episode.created, posts.self, posts.image, posts.imdb_id, posts.quality, posts.create_year as year, posts.private, posts_video.content_id, posts_video.embed, posts_video.download as download, posts_video.episode_id, posts_episode.content_id, posts_episode.name as episodename, posts_episode.id, posts_season.id, posts_episode.season_id, posts_season.name as seasonname FROM posts INNER JOIN posts_video ON posts.id=posts_video.content_id INNER JOIN posts_episode ON posts_episode.id=posts_video.episode_id INNER JOIN posts_season ON posts_season.id=posts_episode.season_id WHERE type LIKE 's%' ORDER BY title ASC";
$file = '../../../sitemaps/episodes.xml';

ob_start();

header("Content-type: text/xml");
echo "<?xml version='1.0' encoding='UTF-8'?>";
echo "<urlset xmlns='http://www.sitemaps.org/schemas/sitemap/0.9' xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' xsi:schemaLocation='http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd'>";

if ($result = mysqli_query($link, $sql)) {
  if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_array($result)) {
      if(preg_match('/&/',$row['name'])){ } else {
        echo "<url>";
        echo "<loc>https://" . $_SERVER['SERVER_NAME'] . "/serie/" .  $row['self'] . "-" . $row['postid'] . "/" . $row['seasonname'] . "-season/" . $row['episodename'] . "-episode</loc>";
        echo "<priority>0.51</priority>";
        echo "</url>";
      }
    }
  }
}
mysqli_free_result($result);

echo "</urlset>";

$htmlStr = ob_get_contents();

ob_end_clean(); 

file_put_contents($file, $htmlStr);

mysqli_close($link);
?>
