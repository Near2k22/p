<?php

include '../../config/db.config.php'; // Database configuration 

$link = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
$sql = "SELECT * FROM posts WHERE posts.type='serie' ORDER BY created DESC";

$file = '../../../sitemaps/series.xml';
$private = "2";
ob_start();

header("Content-type: text/xml");
echo "<?xml version='1.0' encoding='UTF-8'?>";
echo "<urlset xmlns='http://www.sitemaps.org/schemas/sitemap/0.9' xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' xsi:schemaLocation='http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd'>";

if ($result = mysqli_query($link, $sql)) {
  if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_array($result)) {
      if ($row['private'] == $private) {
	 if(preg_match('/&/',$row['title'])){
   	   } else {
             echo "<url>";
             echo "<loc>https://" . $_SERVER['SERVER_NAME'] . "/" . $row['type'] . "/" . $row['self'] . "-" . $row['id'] . "</loc>";
             echo "<priority>0.51</priority>";
             echo "</url>";
           }
         }
       }
     mysqli_free_result($result);
  }
}

echo "</urlset>";

$htmlStr = ob_get_contents();

ob_end_clean(); 

file_put_contents($file, $htmlStr);

mysqli_close($link);

?>
