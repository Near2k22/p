<?php

$db = new mysqli("localhost","watcha","AlphaBravo12","watcha");

// set hits to 0 weekly
$db->query('UPDATE posts SET hit_weekly = 0');

?>
