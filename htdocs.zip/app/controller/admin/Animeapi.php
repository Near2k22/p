<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Animeapi extends Controller {
    public function process() {
        $AuthUser   = $this->getVariable("AuthUser");
        $Route      = $this->getVariable("Route");
        $Settings   = $this->getVariable("Settings");

        $Config['nav']                  = 'tools';

        if($_POST['_ACTION']) {
            foreach ($_POST as $key => $value) {
                if($value) {
                    $Filter[$key] = $value;
                }
            }
            if(count($Filter) > 1) {
                header("location: ".APP.'/admin/animeapi?filter='.json_encode($Filter));
            } else {
                header("location: ".APP.'/admin/animeapi');
            }
        }

        $Filter     = json_decode($_GET['filter'], true);
        $this->setVariable("Filter",$Filter);
        $this->setVariable("Config",$Config);
        if($Filter['type']) {
            $this->listings();
        } elseif(Input::cleaner($_GET['_ACTION']) == 'insert') {
            $this->insert();
        }
        $this->view('animeapi', 'admin');

        $Existings = $this->db->from(null,'
                SELECT
				posts.imdb_id
                FROM `posts`')
            ->all();
    }

    public function listings() {
        $Filter     = $this->getVariable("Filter");
        $Settings   = $this->getVariable("Settings");

        $this->page             = isset($_GET['page']) && is_numeric($_GET['page']) ? $_GET['page'] : 1;

      if ($this->page) $ApiFilter .= '&page=' . $this->page;
        $Client     = new \GuzzleHttp\Client();
        if(($Filter['type'] == 'movie' || $Filter['type'] == 'tv') AND $Filter['q']) {
        $Response   = $Client->request('GET', 'https://api.jikan.moe/v4/anime?q=' . Input::cleaner($Filter['q']) . $ApiFilter. '&order_by=favorites&sort=desc');
        } else if (($Filter['type'] == 'movie' || $Filter['type'] == 'tv') AND $Filter['bulk_ids']) {
          $results = [];
          foreach (explode("\r\n", $Filter['bulk_ids']) as $bulk_id) {
            $_response = $Client->request('GET', 'https://api.jikan.moe/v4/anime/'. $FilterId. '/full');
            $result = json_decode($_response->getBody() , true);
            array_push($results, $result);
          }
        } else {

            $Response   = $Client->request('GET', 'https://api.jikan.moe/v4/top/anime');
        }

        if (!empty($Filter['bulk_ids'])) {
            $Results = [
                'results' => $results,
                'total_results' => count($results),
            ];
        } else {
            $Results = json_decode($Response->getBody() , true);
        }

        foreach ($Results['data'] as $Result) {
            if (Input::cleaner($Filter['type']) == 'movie') {

                $Listings[] = [
                    'id'        => trim($Result['mal_id']),
                    'type'      => 'tv',
                    'link'      => $Result['url'],
                    'title'     => $Result['title'],
                    'image'     => $Result['images']['jpg']['large_image_url'],
                    'mpaa'	=> $Result['Theatrical']
                ];
            } elseif (Input::cleaner($Filter['type']) == 'tv') {

                $Listings[] = [
                  'id'        => trim($Result['mal_id']),
                  'type'      => 'tv',
                  'link'      => $Result['url'],
                  'title'     => $Result['title'],
                  'image'     => $Result['images']['jpg']['large_image_url'],
                    'mpaa'	=> $Result['Theatrical']
                ];
            }
        }

        $this->paginationLimit  = 25;
        $this->totalRecord      = $Results['pagination']['items']['total'];
        $this->pageCount        = ceil($this->totalRecord / $this->paginationLimit);

        $Pagination         = $this->showPagination(APP.'');
        $this->setVariable("Listings",$Listings);
        $this->setVariable("Pagination",$Pagination);

    }

    public function insert() {

        $Settings   = $this->getVariable("Settings");
        $FilterId       = Input::cleaner($_GET['id']);
        $FilterType     = Input::cleaner($_GET['type']);
        $this->db->beginTransaction();
        if ($FilterId) {

            // Guzzle Get
            $Client     = new \GuzzleHttp\Client();
            $Response   = $Client->request(
                'GET',
                'https://api.jikan.moe/v4/anime/'. $FilterId. '/full'
            );
            $Listing    = json_decode($Response->getBody() , true);
            // Listing Check
            if($Listing['data']) {

                // Check Type
                if($FilterType == 'movie') {
                    $Title      = $Listing['data']['title'];
                    $TitleTr    = $Listing['data']['title_english'];
                    $PostType   = 'movie';
                } elseif($FilterType == 'tv') {
                  $Title      = $Listing['data']['title'];
                  $TitleTr    = $Listing['data']['title_english'];
                    $PostType   = 'serie';
                }

                // Check Title and Image
                if ($Title and $Listing['data']['images']['jpg']['large_image_url']) {

                    if (empty($Listing['data']['trailer']['youtube_id']) or $Listing['data']['trailer']['youtube_id'] == "null") {
$Trailer = null;
                    }else{
                        $Trailer = 'https://www.youtube.com/embed/' . $Listing['data']['trailer']['youtube_id'];
                    }

                    // Image URL
                    if($Listing['data']['images']['jpg']['large_image_url']) {
                        $Image = $Listing['data']['images']['jpg']['large_image_url'];
                    }
                    $descripcion = $Listing['data']['synopsis'];
                    // Country// country fix
                     $url = "https://translation.googleapis.com/language/translate/v2?key=AIzaSyCFw9clTmDeSnnXxhC6WFxJAnVYbhYMf7Y";

                    $curl = curl_init($url);
                    curl_setopt($curl, CURLOPT_URL, $url);
                    curl_setopt($curl, CURLOPT_POST, true);
                    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

                    $headers = array(
                        "Content-Type: application/json",
                    );
                    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

                    $data = <<<DATA
{
  "q": ["$descripcion"],
  "target": "es"
}
DATA;

                    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

//for debug only!
                    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
                    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

                    $resp = curl_exec($curl);
                    if(preg_match_all('/"translatedText": "(.*)"/', $resp, $matches)){
                        $explode = explode('"', $matches[1][0]);

                        $descripcion = str_replace("\/", "/", $explode[0]);
                    }

                     // Query Data
                    $Data = array(
                        'type'          => $PostType,
                        'title'         => $Listing['data']['title'],
                        'title_sub'     => $Listing['data']['title_english'],
                        'self'          => Input::seo($Listing['data']['title_english']),
                        'image'         => $Listing['data']['images']['jpg']['large_image_url'],
                        'cover'         => $Listing['data']['images']['jpg']['large_image_url'],
                        'description'   => $descripcion,
                        'country'       => (int)Input::cleaner(107),
                        'imdb'          => Input::cleaner($Listing['data']['score']),
                        'quality'       => "HD",
                        'anime'       => "1",
                        'create_year'   => Input::cleaner($Listing['data']['aired']['prop']['year']),
                        'end_year'   	=> Input::cleaner($Listing['data']['aired']['to']['year']),
                        'duration'      => Input::cleaner($Listing['data']['episodes']),
                        'trailer'       => $Listing['data']['trailer']['embed_url'],
                        'data'          => json_encode($Settings['data'], JSON_UNESCAPED_UNICODE),
                        'imdb_id'       => Input::cleaner($Listing['data']['mal_id']),
                        'status'        => (int)Input::cleaner(1),
                        'mpaa'			=> Input::cleaner($Listing['data']['producers']['name']),
                        'created'       => date('Y-m-d H:i:s')
                    );
                    $this->db->insert('posts')->set($Data);

                    // Post ID
                    $LastId = $this->db->lastId();

                    // Categories
                    foreach ($Listing['data']['genres'] as $Genre) {

                        $Category       = $this->db->from('categories')->where('name',$Genre['name'])->first();
                        if($Category['id']) {
                            $dataarray  = array(
                                "category_id"   => Input::cleaner($Category['id']),
                                "content_id"    => $LastId
                            );
                            $this->db->insert('posts_category')->set($dataarray);
                        }
                    }
                    // Seasons

                    if($_GET['season'] == 'add' AND $PostType == 'serie') {

                        $dataarray = array(
                            "content_id" => $LastId,
                            "name" => "1"
                        );

                        $this->db->insert('posts_season')->set($dataarray);
                        $SeasonId = $this->db->lastId();

                        if ($_GET['episode'] == 'add') {
                            for ($x = 1; $x <= $Listing['data']['episodes']; $x++) {


                                $Data = array(
                                    'name' => $x,
                                    'self' => $x,
                                    'description' => '',
                                    'overview' => '',
                                    'season_id' => $SeasonId,
                                    'content_id' => $LastId,
                                    'image' => "",
                                    'status' => 1,
                                    'created' => date('Y-m-d H:i:s')
                                );
                                $this->db->insert('posts_episode')->set($Data);

                                $EpisodeId = $this->db->lastId();


                            }

                        }
                    }

                    if($_GET['actor'] == 'add') {
                        // Actors
                        $query = 'query ($id: Int) {
        Media (id: $id) {
            characters (sort: ROLE) {
                edges {
                    role,
                    node {
                        id,
                        name {
                            userPreferred,
                        },
                        image {
                            medium,
                        }
                    }
                }
            }
        }
    }';

                        $variables = [
                            'id' => "$FilterId",
                        ];

                        $Credits    = $Client->request(
                            'POST',
                            'https://graphql.anilist.co',
                            [
                                'json' => [
                                    'query' => $query,
                                    'variables' => $variables,
                                ]
                            ]);
                        sleep(2);
                        $Credits    = json_decode($Credits->getBody() , true);

                        foreach ($Credits['data']['Media']['characters']['edges'] as $Credit) {
                            if($Credit['voiceActors']['name']['userPreferred'] AND $Credit['voiceActors']['image']['medium']) {

                                // Check Database
                                $CheckActor = $this->db->from('actors')
                                    ->where('self', Input::seo($Credit['voiceActors']['name']['userPreferred']))
                                    ->or_where('api_id', $Credit['voiceActors']['id'])
                                    ->first();

                                if (!$CheckActor['id'] AND $Credit['voiceActors']['name']['userPreferred']) {
                                    $query = 'query ($id: Int) {
  Staff(id: $id) {
    id
    name {
     full
    }
    description
    image{
      medium
    }
    gender
  }
}';

                                    $variables = [
                                        'id' => $Credit['id'],
                                    ];
                                    $ActorResponse  = $Client->request(
                                        'POST',
                                        'https://graphql.anilist.co',
                                        [
                                            'json' => [
                                                'query' => $query,
                                                'variables' => $variables,
                                            ]
                                        ]);
                                    $Actor          = json_decode($ActorResponse->getBody() , true);
                                    $SettingsData['data']['place_of_birth'] = null;
                                    $SettingsData['data']['deathday']       = null;

                                    $Image = $Actor['data']['Staff']['image']['medium'];

                                    $Data = array(
                                        'name'      => Input::cleaner($Actor['data']['Staff']['name']['full']),
                                        'self'      => Input::seo($Actor['data']['Staff']['name']['full']),
                                        'image'     => $Image,
                                        'biography' => Input::cleaner($Actor['data']['Staff']['description']),
                                        'gender'    => Input::cleaner($Actor['data']['Staff']['gender']),
                                        'data'      => json_encode($SettingsData['data'], JSON_UNESCAPED_UNICODE),
                                        'api_id'    => Input::cleaner($Actor['data']['Staff']['id']),
                                        'imdb_id'   => Input::cleaner($Actor['data']['Staff']['id'])
                                    );
                                    $this->db->insert('actors')->set($Data);
                                    $Actor_id = $this->db->lastId();
                                    $Image      = null;
                                    $SettingsData   = null;
                                    $Path       = null;
                                    $_FILES['image']        = null;
                                } else {
                                    $Actor_id = $CheckActor['id'];
                                }
                                $dataarray = array(
                                    "actor_id"          => $Actor_id,
                                    "character_name"    => Input::cleaner($Credit['node']['name']['userPreferred']),
                                    "character_image"    => Input::cleaner($Credit['node']['image']['medium']),
                                    "content_id"        => $LastId,
                                    "sortable"          => Input::cleaner($Actor['sortable'])
                                );
                                $this->db->insert('posts_actor')->set($dataarray);
                            }

                        }
                    }
                }
            }

            echo json_encode(array(
                "status"    => 'success',
                "text"      => __('Data added successfully')
            ));
        } else {
            echo json_encode(array(
                "status"    => 'danger',
                "text"      => __('Error')
            ));

        }

        $this->db->commit();
        die();
    }
    public function showPagination($url=null, $class = 'active',$small=null) {
        if ($this->totalRecord > PAGE_LIMIT) {
            if($small) {
                $this->html .= '<ul class="pagination mb-3">';
            }else{
                $this->html .= '<ul class="pagination mb-3">';
            }
            for ($i = $this->page - 2; $i < $this->page + 2 + 1; $i ++) {
                if ($i > 0 && $i <= $this->pageCount) {
                    $this->html .= '<li class="page-item ';
                    $this->html .= ($i == $this->page ? 'active' : null);
                    $this->html .= '"><a class="page-link border-0" href=\'' . str_replace('[page]', $i, $url) . '\' rel="nofollow">' . $i . '</a>';
                }
            }
            $this->html .= '</ul>';
            return $this->html;
        }
    }
}
