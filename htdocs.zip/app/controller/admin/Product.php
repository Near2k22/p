<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Product extends Controller
{
    public function process()
    {
        $AuthUser = $this->getVariable("AuthUser");
        $Route = $this->getVariable("Route");
        $Config['title'] = TITLE;
        $Config['description'] = DESC;
        $Config['nav'] = 'product';

        require PATH . '/config/array.config.php';
        $this->setVariable('Listing', $Listing);
        $this->setVariable('Data', $Data);
        $this->setVariable("Config", $Config);

        // Actions
        if ($Listing['id'] and $_POST['_ACTION'] == 'save') {
            $this->update();
        } elseif ($_POST['_ACTION'] == 'save') {
            $this->save();
        }

        $this->view('product', 'admin');
    }

    public function save()
    {
        $AuthUser = $this->getVariable("AuthUser");
        if (empty($Notify)) {
            foreach ($_POST['data'] as $key => $value) {
                if ($value) {
                    $Settings['data'][$key] = $value;
                }
            }
            $Data = array(
                'title'         => Input::cleaner($_POST['title']),
                'description'   => Input::cleaner($_POST['description']),
                'image'   => Input::cleaner($_POST['image']),
                'price'   => Input::cleaner($_POST['price'])
            );
            $this->db->insert('store')->set($Data);

            
            $Notify['type'] = 'success';
            $Notify['text']     = __('Changes Saved'); 
            $this->notify($Notify);
            header("location: " . APP . '/admin/stores');
        } else {
            $this->notify($Notify);
        }
        return $this;
    }

    public function update()
    {
        $AuthUser = $this->getVariable("AuthUser");
        if (empty($Notify)) {
            foreach ($_POST['data'] as $key => $value) {
                if ($value) {
                    $Settings['data'][$key] = $value;
                }
            }
            $Data = array(
                'title'         => Input::cleaner($_POST['title']),
                'description'   => Input::cleaner($_POST['description']),
                'image'   => Input::cleaner($_POST['image']),
                'price'   => Input::cleaner($_POST['price'])
            );
            $this->db->insert('store')->set($Data);

            
            $Notify['type'] = 'success';
            $Notify['text']     = __('Changes Saved'); 
            $this->notify($Notify);
            header("location: " . APP . '/admin/stores');
        } else {
            $this->notify($Notify);
        }
        return $this;
    }
}

