<?php

$infeeds = array(
'

	<div class="list-movie" style="overflow:hidden;width:100%;height:100%;border-radius:5px;">
		<a href="https://bit.ly/3ol2ITo" target="_blank" class="list-media" style="overflow:hidden;border-radius:5px;">
			<div style="position: absolute;top: 50%;left: 50%;transform: translate(-50%, -50%);z-index: 999;overflow:hidden;width: 100%;height:100%;">
            	<div style="background-image:url(https://watcha.movie/public/static/babiato.jpg);height:100%;width:100%;background-size:cover;"></div>
			</div>
			<div class="media media-cover" style="background-color:#000;position:initial;z-index:2;">
				<div style="position: absolute;top: 50%;left: 50%;transform: translate(-50%, -50%);color:#fff;">
					<center>Disable adblock<br> please ?</center>
				</div>
			</div>
		</a>
		<div class="list-caption" style="position:absolute;bottom:32px;">
			<a href="https://bit.ly/3ol2ITo" target="_blank" class="list-title">Advertisement</a>
			<a href="https://watcha.movie/store" target="_blank" class="list-titlesub">Advertisement</a>
		</div>
	</div>

',
'

        <div class="list-movie" style="overflow:hidden;width:100%;height:100%;border-radius:5px;">
                <a href="https://discord.gg/ZPsRQjxZ6Q" target="_blank" class="list-media" style="overflow:hidden;border-radius:5px;">
                        <div style="position: absolute;top: 50%;left: 50%;transform: translate(-50%, -50%);z-index: 999;overflow:hidden;width: 100%;height:100%;">
                <div style="background-image:url(https://watcha.movie/public/static/discord.jpg);height:100%;width:100%;background-size:cover;"></div>
                        </div>
                        <div class="media media-cover" style="background-color:#000;position:initial;z-index:2;">
                                <div style="position: absolute;top: 50%;left: 50%;transform: translate(-50%, -50%);color:#fff;">
                                        <center>Disable adblock<br> please ?</center>
                                </div>
                        </div>
                </a>
                <div class="list-caption" style="position:absolute;bottom:32px;">
                        <a href="https://discord.gg/ZPsRQjxZ6Q" target="_blank" class="list-title">Join our Discord!</a>
                        <a href="https://discord.gg/ZPsRQjxZ6Q" target="_blank" class="list-titlesub">https://discord.gg/ZPsRQjxZ6Q</a>
                </div>
        </div>

',
'

	<div class="list-movie" style="overflow:hidden;width:100%;height:100%;border-radius:5px;">
		<a href="https://my.flaunt7.com/aff.php?aff=578" target="_blank" class="list-media" style="overflow:hidden;border-radius:5px;">
			<div style="position: absolute;top: 50%;left: 50%;transform: translate(-50%, -50%);z-index: 999;overflow:hidden;width: 100%;height:100%;">
            	<div style="background-image:url(https://watcha.movie/public/static/flaunt7.gif);height:100%;width:100%;background-size:cover;"></div>
			</div>
			<div class="media media-cover" style="background-color:#000;position:initial;z-index:2;">
				<div style="position: absolute;top: 50%;left: 50%;transform: translate(-50%, -50%);color:#fff;">
					<center>Disable adblock<br> please ?</center>
				</div>
			</div>
		</a>
		<div class="list-caption" style="position:absolute;bottom:32px;">
			<a href="https://my.flaunt7.com/aff.php?aff=578" target="_blank" class="list-title">Flaunt7 Servers</a>
			<a href="https://watcha.movie/store" target="_blank" class="list-titlesub">Advertisement</a>
		</div>
	</div>

'
);

?>
