
<div class="app-content pt-md-3">
    <?php echo ads($Ads,3,'mb-3');?>
    <?php

    foreach ($HomeModules as $HomeModule) {
        $ModuleData       = json_decode($HomeModule['data'], true);
        require PATH . '/theme/view/module/'.$HomeModule['module_file'].'.php';
    }
?>
</div>
