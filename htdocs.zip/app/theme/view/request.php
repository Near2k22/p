<?php require PATH . '/theme/view/common/header.php';?>
<div class="app-content">
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo APP;?>"><?php echo __('Home');?></a></li>
            <li class="breadcrumb-item active"><a href="<?php echo APP.'/request';?>"><?php echo __('Request');?></a></li>
        </ol>
    </nav>
	<div class="text-24 text-white font-weight-bold">Make a Request</div>
	<div class="text-12 text-white">Make a request by filling out the form below. By making a request you agree to the following rules, if you don't follow the rules we'll remove your request and move on.
<br>
<br>
&#8226; You must provide us with the Title of the show or movie.
<br>
&#8226; You must provide us a link to IMDb, we'll also accept TMDb.
<br>
&#8226; Do not include year of release, this clutters everything up and we can get that info from IMDb or TMDb.
<br>
&#8226; TV Show requests are currently limited to series with less than 100 episodes, if you'd like to request TV shows with more than 100 episodes please consider donating and getting one of our perks! Donate <a href="https://watcha.movie/store" style="text-decoration: none;">HERE</a>
<br>

</div>
		<br>
	<form method="post" action="/request?status=success" autocomplete="off"> 
        <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label class="custom-label"><?php echo __('Movie or Series Title');?></label>
                    <input type="text" name="title" class="form-control form-control-lg" placeholder="<?php echo __('Movie or Series Title');?>" required>
                </div>
                <div class="form-group">
                	<label class="custom-label"><?php echo __('Movie or Series');?></label>
                	<select name="type" class="custom-select" required>
                  		<option value="">
                      		<?php echo __('Select One');?>
                    	</option>
                  		<option value="movie">
                      		<?php echo __('Movie');?>
                    	</option>
                    	<option value="series">
                        	<?php echo __('Series');?>
                    	</option>
               		</select>
                </div>
                <div class="form-group">
                    <label class="custom-label"><?php echo __('IMDb URL');?></label>
                    <input type="url" name="url" class="form-control form-control-lg" placeholder="<?php echo __('Insert IMDb URL');?>" required>
                </div>
					<br>
                <button type="submit" name="save" class="btn btn-theme btn-lg d-block d-md-inline-block mb-4 px-5" style="width:400px;" <?php if(get($Settings,'data.requests','general') == 1) { } else { ?>disabled<?php } ?> ><?php if(get($Settings,'data.requests','general') == 1) { echo __('Submit Request'); } else { echo get($Settings,'data.request_message','general'); } ?></button>
        	</div>
		</div>
	</form>
</div>
<?php require PATH . '/theme/view/common/footer.php';?>
