<?php
$link = "https://api.jikan.moe/v4/anime/49470/full";

    $ch =   curl_init();
    curl_setopt($ch, CURLOPT_URL, $link);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $resultado = curl_exec($ch);

    if(preg_match_all('/","string":"(.*)"/', $resultado, $matches)){
        $explode = explode('"', $matches[1][0]);

        $respuesta = str_replace("\/", "/", $explode[0]);
    }
?>