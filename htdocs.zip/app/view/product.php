<?php require PATH . '/view/common/header.php';?>
<form method="post" autocomplete="off" enctype="multipart/form-data" class="form-content">
    
    <div class="d-md-flex">
        <div class="flex-fill">
            <input type="hidden" name="_ACTION" value="save">
            <input type="hidden" name="_FORMTOKEN" value="<?php echo $Token; ?>">
            <div class="tab-content">
                <div class="tab-pane show active" id="contents" role="tabpanel" aria-labelledby="contents-tab">
                    <?php require PATH . '/view/common/post.tab.store.php';?>
                </div>
            </div>
        </div>
    </div>
            <button type="submit" class="btn btn-theme btn-lg btn-block mb-3"><?php echo __('Save Changes');?></button> 
</form> 
<?php require PATH . '/view/common/footer.php';?>