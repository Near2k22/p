<?php

include '../app/config/db.config.php'; // Database configuration 

$link = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
$sql = "SELECT * FROM posts LEFT JOIN posts_video ON posts.id = posts_video.content_id ORDER BY posts.created ASC";
$private = "2";
if ($result = mysqli_query($link, $sql))
{
    if (mysqli_num_rows($result) > 0)
    {
        while ($row = mysqli_fetch_array($result))
        {
			
			if ($row['private'] == $private) 
			{
		if(preg_match('/movie/',$row['type'])){
            echo $row['title'] . ' - ' . $row['embed'];
			echo "<br>";
        }
        }
        }
        mysqli_free_result($result);
    }
    else
    {
        echo "<?php echo __('No records matching your query were found');?>";
    }
}
else
{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
mysqli_close($link);
?>
