<?php

        $id = $_GET['id'];
        $tag = $_GET['tag'];
        $t = $_GET['t'];
        $e = $_GET['e'];

        $ch =   curl_init();
                curl_setopt($ch, CURLOPT_URL, "https://api.mycdn.moe/video/$id-$t"."x$e");
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $resultado = curl_exec($ch);

        if(preg_match_all('/Se produjo un error. (.*)./', $resultado, $matches)){
            $explode = explode('"', $matches[1][0]);

            $respuesta = str_replace(".</div", "", $explode[0]);
        }
        if ($respuesta == "El Reproductor no se puede ver") {
          header("Location: https://api.mycdn.moe/video/$tag-$t"."x$e");
        }else {
          header("Location: https://api.mycdn.moe/video/$id-$t"."x$e");
        }
